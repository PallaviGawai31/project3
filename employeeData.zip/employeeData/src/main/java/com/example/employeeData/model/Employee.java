package com.example.employeedata.model;

import jakarta.persistence.*;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;   // FIXED (Long instead of int)

    private String name;
    private String email;
    private String mobile;

    public Employee() {}

    public Employee(Long id, String name, String email, String mobile){
        this.id = id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
    }

    // getters & setters
    public Long getId() {
        return id;
    }

    public String getName() {   // 🔥 MUST BE EXACT NAME
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }

    //  SETTERS
    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {   // 🔥 MUST BE EXACT
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
