package com.example.employeedata.service;

import com.example.employeedata.model.Employee;
import com.example.employeedata.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    private final EmployeeRepository repository;

    // Constructor Injection (BEST PRACTICE)
    public EmployeeService(EmployeeRepository repository) {
        this.repository = repository;
    }

    //  Get all employees
    public List<Employee> getAllEmployees() {
        return repository.findAll();
    }

    //  Get employee by ID
    public Optional<Employee> getEmployeeById(Long id) {
        return repository.findById(id);
    }

    //  Create / Save employee
    public Employee saveEmployee(Employee employee) {
        return repository.save(employee);
    }

    //  Update employee
    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Employee employee = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        employee.setName(employeeDetails.getName());
        employee.setEmail(employeeDetails.getEmail());
        employee.setMobile(employeeDetails.getMobile());

        return repository.save(employee);
    }

    //  Delete employee
    public void deleteEmployee(Long id) {
        repository.deleteById(id);
    }
}